/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetohelpdesk;

/**
 *
 * @author programacao1
 */
public class Servico {
    public int identificador;
    public String usuario;
    public String dataAbertura;
    public String dataConclusao;
    public String problema;
    public String atendente;
    public boolean situacao;

    public boolean isSituacao() {
        return situacao;
    }

    public void setSituacao(boolean situacao) {
        this.situacao = situacao;
    }

    public int getIdentificador() {
        return identificador;
    }

    public void setIdentificador(int identificador) {
        this.identificador = identificador;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getDataAbertura() {
        return dataAbertura;
    }

    public void setDataAbertura(String dataAbertura) {
        this.dataAbertura = dataAbertura;
    }

    public String getDataConclusao() {
        return dataConclusao;
    }

    public void setDataConclusao(String dataConclusao) {
        this.dataConclusao = dataConclusao;
    }

    public String getProblema() {
        return problema;
    }

    public void setProblema(String problema) {
        this.problema = problema;
    }

    public String getAtendente() {
        return atendente;
    }

    public void setAtendente(String atendente) {
        this.atendente = atendente;
    }
    public void imprimirAtendimentoAberto(){        
        System.out.println("Identificador = " + this.getIdentificador());
        System.out.println("Usuario = " + this.getUsuario());
        System.out.println("Data Solicitação = " + this.getDataAbertura());
        System.out.println("Problema = " + this.getProblema());
        
    }
}
