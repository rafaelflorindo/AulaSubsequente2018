/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetohelpdesk;

/**
 *
 * @author programacao1
 */
public class ProjetoHelpDesk {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Servico serv1 = new Servico();
        serv1.setIdentificador(1);
        serv1.setUsuario("Néia");
        serv1.setDataAbertura("27/02/2019 20:55:35");
        serv1.setProblema("Problema: Defeitos em todos os teclados do laboratório de Informática Pró-info!!!");
        serv1.imprimirAtendimentoAberto();
        //serv1.setAtendente("Eduardo");
    } 
}
